
		<object width="470" height="315">
      <param name="movie" value="https://www.youtube.com/v/?version=3&amp;hl=vi_VN">
      </param>
      <param name="allowFullScreen" value="true">
      </param>
      <param name="allowscriptaccess" value="always">
      </param>
      <embed src="https://www.youtube.com/v/?version=3&amp;hl=vi_VN" type="application/x-shockwave-flash" width="470" height="315" allowscriptaccess="always" allowfullscreen="true" wmode="transparent"></embed>
    </object>
	